/**
 *  @author : Aakshaye M Gaikar
 *  @version: 1.0
 *  @revision: 1
 */
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;
/**
 * Percolation class implementing Percolation API
 */
public class Percolation {

    private final int n;
    private boolean[][] grid;
    private final WeightedQuickUnionUF uf;
    private final int numSites;
    private int openSites;
    public Percolation(int n) {
        if (n <= 0)
            throw new IllegalArgumentException();
        this.n = n;
        grid = new boolean[n+1][n+1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                grid[i][j] = false;
            }
        }
        numSites = (n * n) + 2;
        uf = new WeightedQuickUnionUF(numSites); // virtual top and bottom sites
        openSites = 0;
        connectTopBottomLayer();

    }
    public void open(int row, int col) {
        validateIndex(row, col);
        if (!grid[row][col]) {
            grid[row][col] = true;
            openSites++;
        } else {
            return;
        }
        // top
        if ((row - 1) > 0 && isOpen(row - 1, col) &&
                !uf.connected(rowcolTo1D(row, col), rowcolTo1D(row - 1, col))) {
            uf.union(rowcolTo1D(row, col), rowcolTo1D(row -1, col));
        }
        // right
        if ((col + 1) <= n && isOpen(row, col + 1) &&
                !uf.connected(rowcolTo1D(row, col), rowcolTo1D(row, col +1))) {
            uf.union(rowcolTo1D(row, col), rowcolTo1D(row, col + 1));
        }
        // bottom
        if ((row + 1) <= n && isOpen(row + 1, col) &&
                !uf.connected(rowcolTo1D(row, col), rowcolTo1D(row + 1, col))) {
            uf.union(rowcolTo1D(row, col), rowcolTo1D(row + 1, col));
        }
        // left
        if ((col - 1) > 0 && isOpen(row, col - 1) &&
                !uf.connected(rowcolTo1D(row, col), rowcolTo1D(row, col - 1))) {
            uf.union(rowcolTo1D(row, col), rowcolTo1D(row, col - 1));
        }
    }
    public boolean isOpen(int row, int col) {
        validateIndex(row, col);
        if (grid[row][col]) return true;
            return false;
    }
    public boolean isFull(int row, int col) {
        validateIndex(row, col);
        // root is virtual top
        if (isOpen(row, col) && uf.connected(rowcolTo1D(row, col), 0))
            return true;
        return false;
    }
    public int numberOfOpenSites() {
        return openSites;
    }
    public boolean percolates() {
        if (uf.connected(0, numSites -1) && numberOfOpenSites() > 0)
            return true;
        return false;
    }
    private int rowcolTo1D(int row, int col) {
        validateIndex(row, col);
        return col + (row - 1) * n;
    }
    private void connectTopBottomLayer() {
        // Connect top layer to virtual top
        for (int i = 1; i <= n; i++) {
            uf.union(0, i);
        }
        // Connect bottom layer to virtual bottom
        for (int i = this.numSites - 2; i >= numSites - n - 1; i--) {
            uf.union(numSites -1, i);
        }
    }
    private void validateIndex(int row, int col) {
        if (row <= 0 || row > n) {
            throw new IllegalArgumentException("row Index out of bounds" + row);
        }
        if (col <= 0 || col > n) {
            throw new IllegalArgumentException("column Index out of bounds" + col);
        }
    }
    public static void main(String[] args) {
        In in = new In(args[0]);      // input file
        int n = in.readInt();         // n-by-n percolation system

        // repeatedly read in sites to open and draw resulting system
        Percolation perc = new Percolation(n);
         while (!in.isEmpty()) {
            int i = in.readInt();
            int j = in.readInt();
            StdOut.println(i + " " + j);
            perc.open(i, j);
        }
    }
}
